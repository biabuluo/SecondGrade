import pandas as pd
import numpy as np
import warnings
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn import metrics
import random


pd.set_option('display.max_columns', None)

# 忽视警告
warnings.filterwarnings("ignore")

class population:   #种群类
    #回归分析功能块
    def regressionfunc(self, X, y):
        # logistic regression
        # 将数据集以7：3的比例，拆分为训练数据和测试数据：
        train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=10)
        model = LogisticRegression()
        model.fit(train_X, train_y)
        prediction = model.predict(test_X)
        return metrics.accuracy_score(prediction, test_y)

    def __init__(self, X, y, limit):
        self.FINISHED_LIMIT = 0      #终止界限
        self.ACCURACY_LIMIT =limit    #self.regressionfunc(X, y)   #准确率限界(以初始状态的特征集做限界)
        self.CHROMOSOME_SIZE = 13
        self.SELECT_NUMBER = 4
        self.max_last = 0     #上一代种群中最大准确率
        self.diff_last = 10000  #上一次计算的改变量

    #算法退出模块
    def is_finished(self, fitnesses):
        max_current = 0
        for v in fitnesses:
            if v > max_current:
                max_current = v    #寻找该代种群最优染色体
        print('max_current:', max_current)
        diff = max_current - self.max_last    #适应度改变大小
        #这里判断连续两代的改变量如果都等于0，则停止迭代
        if diff == self.FINISHED_LIMIT and self.diff_last < self.FINISHED_LIMIT:
            return True
        else:
            self.diff_last = diff
            self.max_last = max_current
            return False

    def initchrom(self):    #生成4条初始染色体
        chromosome_states = []
        count = 0
        for i in range(1, 100):
            chromosome_state = []
            flag = True
            for j in range(1, self.CHROMOSOME_SIZE+1):
                chromosome_state.append(random.randint(0, 1))
            # print(chromosome_state)
            for k in chromosome_states:
                if k==chromosome_state:
                    flag = False
            if flag:
                chromosome_states.append(chromosome_state)
                count += 1
                if count == 4:
                    # print('chromosome_states:',chromosome_states)
                    return chromosome_states
            else:
                continue

    def mapping(self, chromosome_state):  #生成X
        temp_attr = []
        for (i, j) in zip(chromosome_state, attri):
            if i == 1:
                temp_attr.append(j)
        return df[temp_attr]


    def fitness(self, chromosome_states):   #计算适应度
        fitnesses = []
        for chromosome_state in chromosome_states:  #遍历所有染色体
            X = self.mapping(chromosome_state)
            fitnesses.append(self.regressionfunc(X, y))
        return fitnesses


    def filter(self, chromosome_states, fitnesses):    #自然选择模块
        # 准确率小于accuracy_limit被淘汰
        index = len(fitnesses) - 1
        while index >= 0:
            index -= 1
            if fitnesses[index] < self.ACCURACY_LIMIT:
                chromosome_states.pop(index)   #弹出不符合的染色体
                fitnesses.pop(index)
        # 遴选
        selected_index = [0] * len(chromosome_states)
        for i in range(self.SELECT_NUMBER-1):
            # 随机选择染色体，然后得到相应的索引
            j = chromosome_states.index(random.choice(chromosome_states))
            selected_index[j] += 1
        return selected_index

    #交叉产生下一代：
    def crossover(self, chromosome_states, selected_index):
        chromosome_states_new = []
        index = len(chromosome_states)-1
        while index >= 0:  # 遍历完所有的染色体组的染色体（其中下标-1代表最后一个染色体的索引）
            print('index:', index)
            index -= 1
            chromosome_state = chromosome_states.pop(index)
            print('弹出后的染色体组chromosome_states_3：', chromosome_states)
            print('弹出的染色体：', chromosome_state)
            for i in range(selected_index[index]):
                chromosome_state_x = random.choice(chromosome_states)  # 随机选择一个染色体
                print('chromosome_state_x:', chromosome_state_x)
                pos = random.choice(range(1, self.CHROMOSOME_SIZE - 1))  # 随机[1, 2, 3, 4]其中的一个数
                print('pos( 随机[1, 2, 3, 4]其中的一个数):', pos)
                chromosome_states_new.append(chromosome_state[:pos] + chromosome_state_x[pos:])
                print('chromosome_states_new:', chromosome_states_new)
            chromosome_states.insert(index, chromosome_state)  # 恢复原染色体组
            print('chromosome_states_4:', chromosome_states)
        return chromosome_states_new  # 返回得到的新的染色体组

    def runpopulation(self):
        chromosome_states = self.initchrom()
        print('初始染色体组：', chromosome_states)
        n = 100  #迭代次数
        while n > 0:
            n -= 1
            #适应度计算
            fitnesses = self.fitness(chromosome_states)
            if self.is_finished(fitnesses):
                break
            print('1:', fitnesses)
            #遴选
            selected_index = self.filter(chromosome_states, fitnesses)
            print('2:', selected_index)
            print('chromosome_states_2:', chromosome_states)
            #产生下一代
            chromosome_states = self.crossover(chromosome_states, selected_index)
            print('3:', chromosome_states)
            print(str(n)+'.........................')  #迭代次数
        fitnesses = self.fitness(chromosome_states)
        print('fitnesses:', fitnesses)
        print(chromosome_states)
        maxfitness = 0
        maxindex = 0
        for i in range(0, len(fitnesses)):
            if fitnesses[i] > maxfitness:
                maxfitness = fitnesses[i]
                maxindex = i
        maxchromosome = chromosome_states[maxindex]
        bestattri = []
        for (i, j) in zip(maxchromosome, attri):
            if i == 1:
                bestattri.append(j)
        print('选择特征：',bestattri)
        print('准确率：', maxfitness)



if __name__ == '__main__':
    df = pd.read_csv('data\heart.csv')
    X = df[['age',  # 年龄
            'sex',  # 性别
            'cp',  # 心绞痛病史，1:典型心绞痛，2:非典型心绞痛，3:无心绞痛，4:无症状
            'trestbps',  # 静息血压
            'chol',  # 胆固醇含量
            'fbs',  # 空腹时是否血糖高，如果空腹血糖大于120 mg/dl，值为1，否则值为0
            'restecg',  # 静息时的心电图特征。0:正常。1:  ST-T波有异常。2:根据Estes准则，有潜在的左
            'thalach',  # 最大心率
            'exang',  # 运动是否会导致心绞痛,1表示会，0表示不会
            'oldpeak',  # 运动相比于静息状态，心电图中的ST-T波是否会被压平。1表示会，0表示不会
            'slope',  # 心电图中ST波峰值的坡度（1:上升，2:平坦，3:下降)
            'ca',  # 心脏周边大血管的个数(0-3)
            'thal']]  # 是否患有地中海贫血症(3:无，6: fixed defect; 7: reversable defect)
    y = df['target']  # 标签列。是否有心脏病，0表示没有，1表示有
    attri = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca',
             'thal']

    def funcmodule(X, y):
        try:
            mypopulation = population(X, y, 0.78)
            print(mypopulation.ACCURACY_LIMIT)
            mypopulation.runpopulation()
        except IndexError:
            print('重新执行！')
            raise IndexError

    # 对标签集进行编码
    encoder = LabelEncoder()
    y = encoder.fit_transform(y)
    while True:
        try:
            funcmodule(X, y)
        except IndexError:
            continue
        else:
            break



