import pandas as pd
import numpy as np
import warnings
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn import metrics


pd.set_option('display.max_columns', None)

# 忽视警告
warnings.filterwarnings("ignore")

# 解决类
class solution:
        def __init__(self, df):
                self.df = df
                # 载入特征和标签集
                self.X = df[['age',   #年龄
                                'sex',   #性别
                                'cp',    # 心绞痛病史，1:典型心绞痛，2:非典型心绞痛，3:无心绞痛，4:无症状
                                'trestbps', #静息血压
                                'chol',  #胆固醇含量
                                'fbs',   #空腹时是否血糖高，如果空腹血糖大于120 mg/dl，值为1，否则值为0
                                'restecg', #静息时的心电图特征。0:正常。1:  ST-T波有异常。2:根据Estes准则，有潜在的左
                                'thalach', #最大心率
                                'exang', # 运动是否会导致心绞痛,1表示会，0表示不会
                                'oldpeak', # 运动相比于静息状态，心电图中的ST-T波是否会被压平。1表示会，0表示不会
                                'slope', # 心电图中ST波峰值的坡度（1:上升，2:平坦，3:下降)
                                'ca', #心脏周边大血管的个数(0-3)
                                'thal']] # 是否患有地中海贫血症(3:无，6: fixed defect; 7: reversable defect)
                self.y = df['target'] #  标签列。是否有心脏病，0表示没有，1表示有
                # 对标签集进行编码
                encoder = LabelEncoder()
                self.y = encoder.fit_transform(self.y)
                self.attri = ['age','sex', 'cp',  'trestbps', 'chol',  'fbs', 'restecg','thalach','exang','oldpeak', 'slope', 'ca', 'thal']
                self.isornot = [1,1,1,1,1,1,1,1,1,1,1,1,1]   #初始状态
                self.bestisornot = self.isornot.copy()
                self.bestaccu = self.regressionfunc(self.X, self.y)
                self.hierar = 13

        def regressionfunc(self, X, y):
        # logistic regression
        # 将数据集以7：3的比例，拆分为训练数据和测试数据：
            train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=101)
            model = LogisticRegression()
            model.fit(train_X, train_y)
            prediction = model.predict(test_X)
            return metrics.accuracy_score(prediction, test_y)

        def constraint(self, isornot):
            # 根据isornot list来选择特征计算准确值
            temp_attr = []
            for (i, j) in zip(isornot, self.attri):
                if i == 1:
                    temp_attr.append(j)
            X = self.df[temp_attr]
            accur_tmp = self.regressionfunc(X, self.y)
            if accur_tmp >= self.bestaccu:
                return [True, accur_tmp]
            else:
                return [False]

        def traceback(self, dimension):
            if dimension > self.hierar:
                return
            else:
                self.isornot[dimension-1] = 0
                tmp_list = self.constraint(self.isornot)
                if tmp_list[0]:
                    self.bestaccu = tmp_list[1]
                    self.bestisornot = self.isornot.copy()
                    self.traceback(dimension+1)
                self.isornot[dimension-1] = 1
                self.traceback(dimension + 1)

        def runfunc(self):
            self.traceback(1)
            self.output()

        def output(self):
            bestattri=[]
            for (i,j) in zip(self.bestisornot, self.attri):
                if i==1:
                    bestattri.append(j)
            print('选择的特征：', bestattri)
            print('准确率：', self.bestaccu)


mysolution = solution(pd.read_csv('data/heart.csv'))
mysolution.runfunc()



